using GestionNotes.Blazor.Components;
using Blazored.LocalStorage;
using System.Net.Http;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddBlazoredLocalStorage();

// Ajouter des services au conteneur.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Ajouter le service HttpClient avec une adresse de base
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:5001/") });

var app = builder.Build();

// Configurer le pipeline de requ�tes HTTP.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // La valeur HSTS par d�faut est de 30 jours. Vous pouvez vouloir changer cela pour les sc�narios de production, voir https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
